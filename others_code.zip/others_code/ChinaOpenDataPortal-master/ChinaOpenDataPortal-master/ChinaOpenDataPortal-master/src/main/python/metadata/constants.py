"""Constants"""
DEFAULT_ENCODING = 'utf-8'
REQUEST_TIME_OUT = 10000

PROVINCE_CURL_JSON_PATH = 'D:\科研\ChinaOpenDataPortal-master\ChinaOpenDataPortal-master\src\main\python\metadata\config\curl.json'

PROVINCE_LIST = ['shandong', 'jiangsu']

METADATA_SAVE_PATH = 'D:\科研\ChinaOpenDataPortal-master\ChinaOpenDataPortal-master\src\main\python\metadata\json\data\\'