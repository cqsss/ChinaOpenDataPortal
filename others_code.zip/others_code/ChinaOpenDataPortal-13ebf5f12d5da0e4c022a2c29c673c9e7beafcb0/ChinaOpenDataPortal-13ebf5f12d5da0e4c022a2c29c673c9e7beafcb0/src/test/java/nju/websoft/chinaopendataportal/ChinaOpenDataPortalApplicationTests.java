package nju.websoft.chinaopendataportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChinaOpenDataPortalApplicationTests {

    @Test
    void contextLoads() {
    }

}
