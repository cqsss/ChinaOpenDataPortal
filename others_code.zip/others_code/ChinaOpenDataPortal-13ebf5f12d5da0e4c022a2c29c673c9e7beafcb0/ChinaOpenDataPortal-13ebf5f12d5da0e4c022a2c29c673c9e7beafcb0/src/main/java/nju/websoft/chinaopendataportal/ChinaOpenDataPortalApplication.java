package nju.websoft.chinaopendataportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChinaOpenDataPortalApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChinaOpenDataPortalApplication.class, args);
    }

}
