"""Constants"""
DEFAULT_ENCODING = 'utf-8'
REQUEST_TIME_OUT = 120

PROVINCE_CURL_JSON_PATH = './config/curl.json'

PROVINCE_LIST = ['sichuan', 'guizhou']

METADATA_SAVE_PATH = './json/data/'