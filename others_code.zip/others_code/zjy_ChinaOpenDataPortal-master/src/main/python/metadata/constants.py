"""Constants"""
DEFAULT_ENCODING = 'utf-8'
REQUEST_TIME_OUT = 20

PROVINCE_CURL_JSON_PATH = 'src\main\python\metadata\config\curl.json'

PROVINCE_LIST = ['shandong', 'jiangsu']

METADATA_SAVE_PATH = '/home/qschen/Data/ChinaOpenData/metadata/'
